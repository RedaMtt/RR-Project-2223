"use strict";(self["webpackChunkmy_expenses"]=self["webpackChunkmy_expenses"]||[]).push([[78],{6078:(e,t,s)=>{s.r(t),s.d(t,{startStatusTap:()=>a});var n=s(65),r=s(4074),o=s(6587);
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
const a=()=>{const e=window;e.addEventListener("statusTap",(()=>{(0,n.wj)((()=>{const t=e.innerWidth,s=e.innerHeight,a=document.elementFromPoint(t/2,s/2);if(!a)return;const i=(0,r.a)(a);i&&new Promise((e=>(0,o.c)(i,e))).then((()=>{(0,n.Iu)((async()=>{i.style.setProperty("--overflow","hidden"),await(0,r.s)(i,300),i.style.removeProperty("--overflow")}))}))}))}))}}}]);
//# sourceMappingURL=78-legacy.26687051.js.map