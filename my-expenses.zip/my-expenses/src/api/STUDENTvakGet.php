<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

define ('INDEX', true);
require 'inc/dbcon.php';
require 'inc/base.php';

$sql="select Vak_Student.Vak, Vak.Naam, Vak_Student.Student, Student.Voornaam FROM Vak_Student join Vak on Vak_Student.Vak = Vak.Code join Student on Vak_Student.Student = Student.StudentNummer ";

$result = $conn -> query($sql);

if (!$result) {
    $response['code'] = 7;
    $response['status'] = $api_response_code[$response['code']]['HTTP Response'];
    $response['data'] = $conn->error;
    deliver_response($response);
}

$response['data'] = getJsonObjFromResult($result);
$result->free();
$conn->close();
deliver_JSONresponse($response);
?>